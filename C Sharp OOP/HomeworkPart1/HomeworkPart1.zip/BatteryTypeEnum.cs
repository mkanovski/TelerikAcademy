﻿using System;

namespace HomeworkPart1
{
    public enum BatteryTypeEnum
    {
        Unknown = 0,
        LiIon = 1,
        NiMH = 2,
        NiCd = 3
    }
}
